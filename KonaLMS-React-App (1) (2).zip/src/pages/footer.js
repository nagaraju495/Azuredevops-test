import React from 'react'

function footer() {
    return (
        <div>
              <div className="flex justify-center text-sm font-medium py-12">
                    <ul className="flex flex-row  space-x-4">
                        <li>© 2020 Digital Lync</li>
                      <a href="#"> <li>Privacy Policy</li> </a>  
                    </ul>

                </div>
        </div>
    )
}

export default footer
